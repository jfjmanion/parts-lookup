-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 05, 2014 at 02:18 AM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `parts`
--

-- --------------------------------------------------------

--
-- Table structure for table `Locations`
--

CREATE TABLE IF NOT EXISTS `Locations` (
  `Part_id` varchar(32) NOT NULL DEFAULT '',
  `PartLocation` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`Part_id`,`PartLocation`),
  KEY `Part_id` (`Part_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Locations`
--


-- --------------------------------------------------------

--
-- Table structure for table `Parts`
--

CREATE TABLE IF NOT EXISTS `Parts` (
  `Id` varchar(32) NOT NULL DEFAULT '',
  `PartName` varchar(128) DEFAULT NULL,
  `PartNotes` text,
  PRIMARY KEY (`Id`),
  KEY `PartId` (`Id`),
  KEY `PartName` (`PartName`),
  KEY `PartName_2` (`PartName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Parts`
--

